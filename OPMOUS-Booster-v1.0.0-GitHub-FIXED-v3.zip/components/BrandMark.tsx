import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import colors from '@/constants/colors';

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <View style={styles.row}>
      <View style={styles.logoFrame}>
        <Image
        accessibilityLabel="OPMOUS logo"
        source={require('@/assets/images/icon.png')}
        style={[styles.logo, compact && styles.logoCompact]}
        />
      </View>
      {!compact && (
        <View>
          <Text style={styles.wordmark}>OPMOUS</Text>
          <Text style={styles.caption}>BOOSTER</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { alignItems: 'center', flexDirection: 'row', gap: 10 },
  logoFrame: { borderColor: colors.light.cyan, borderRadius: 15, borderWidth: 1, padding: 2, shadowColor: colors.light.cyan, shadowOpacity: 0.8, shadowRadius: 8 },
  logo: { borderRadius: 12, height: 42, width: 42 },
  logoCompact: { borderRadius: 10, height: 30, width: 30 },
  wordmark: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: 2 },
  caption: { color: colors.light.primary, fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 2.5, marginTop: 1 },
});