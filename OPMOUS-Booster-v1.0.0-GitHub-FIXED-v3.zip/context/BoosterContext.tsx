import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { Alert } from 'react-native';

export type Game = {
  id: string;
  name: string;
  packageName: string;
  profile: 'Balanced' | 'Performance' | 'Battery Saver';
  lastPlayed?: string;
};

type BoosterContextValue = {
  games: Game[];
  addGame: (game: Omit<Game, 'id'>) => void;
  removeGame: (id: string) => void;
  launchGame: (game: Game) => void;
  isSessionActive: boolean;
  sessionSeconds: number;
  startSession: (gameName?: string) => void;
  stopSession: () => void;
  profile: Game['profile'];
  setProfile: (profile: Game['profile']) => void;
  liteMode: boolean;
  setLiteMode: (value: boolean) => void;
  panelEnabled: boolean;
  setPanelEnabled: (value: boolean) => void;
  hapticsEnabled: boolean;
  setHapticsEnabled: (value: boolean) => void;
};

const BoosterContext = createContext<BoosterContextValue | null>(null);

const GAMES_KEY = '@opmous/games';
const SETTINGS_KEY = '@opmous/settings';

export function BoosterProvider({ children }: { children: React.ReactNode }) {
  const [games, setGames] = useState<Game[]>([]);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [profile, setProfile] = useState<Game['profile']>('Balanced');
  const [liteMode, setLiteMode] = useState(false);
  const [panelEnabled, setPanelEnabled] = useState(true);
  const [hapticsEnabled, setHapticsEnabled] = useState(true);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(GAMES_KEY), AsyncStorage.getItem(SETTINGS_KEY)]).then(
      ([savedGames, savedSettings]) => {
        if (savedGames) setGames(JSON.parse(savedGames) as Game[]);
        if (savedSettings) {
          const settings = JSON.parse(savedSettings) as Partial<{
            profile: Game['profile'];
            liteMode: boolean;
            panelEnabled: boolean;
            hapticsEnabled: boolean;
          }>;
          if (settings.profile) setProfile(settings.profile);
          if (typeof settings.liteMode === 'boolean') setLiteMode(settings.liteMode);
          if (typeof settings.panelEnabled === 'boolean') setPanelEnabled(settings.panelEnabled);
          if (typeof settings.hapticsEnabled === 'boolean') setHapticsEnabled(settings.hapticsEnabled);
        }
      },
    ).catch(() => undefined);
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(GAMES_KEY, JSON.stringify(games)).catch(() => undefined);
  }, [games]);

  useEffect(() => {
    AsyncStorage.setItem(
      SETTINGS_KEY,
      JSON.stringify({ profile, liteMode, panelEnabled, hapticsEnabled }),
    ).catch(() => undefined);
  }, [profile, liteMode, panelEnabled, hapticsEnabled]);

  useEffect(() => {
    if (!isSessionActive) return;
    const timer = setInterval(() => setSessionSeconds((seconds) => seconds + 1), 1000);
    return () => clearInterval(timer);
  }, [isSessionActive]);

  const value = useMemo<BoosterContextValue>(
    () => ({
      games,
      addGame: (game) => {
        setGames((current) => [
          ...current,
          { ...game, id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}` },
        ]);
      },
      removeGame: (id) => setGames((current) => current.filter((game) => game.id !== id)),
      launchGame: (game) => {
        setGames((current) =>
          current.map((item) =>
            item.id === game.id ? { ...item, lastPlayed: new Date().toISOString() } : item,
          ),
        );
        Alert.alert(
          'Launch ready',
          game.packageName
            ? `Game shortcut saved for ${game.name}. A standalone build is required to launch installed packages directly.`
            : 'Add the Android package name in My Games to create a launcher shortcut.',
        );
      },
      isSessionActive,
      sessionSeconds,
      startSession: () => {
        setSessionSeconds(0);
        setIsSessionActive(true);
      },
      stopSession: () => {
        setIsSessionActive(false);
        setSessionSeconds(0);
      },
      profile,
      setProfile,
      liteMode,
      setLiteMode,
      panelEnabled,
      setPanelEnabled,
      hapticsEnabled,
      setHapticsEnabled,
    }),
    [games, isSessionActive, sessionSeconds, profile, liteMode, panelEnabled, hapticsEnabled],
  );

  return <BoosterContext.Provider value={value}>{children}</BoosterContext.Provider>;
}

export function useBooster() {
  const value = useContext(BoosterContext);
  if (!value) throw new Error('useBooster must be used inside BoosterProvider');
  return value;
}