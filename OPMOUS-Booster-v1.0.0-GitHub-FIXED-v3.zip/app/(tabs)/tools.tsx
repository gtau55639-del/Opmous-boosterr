import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import colors from '@/constants/colors';

const tools = [
  { label: 'Screenshot', icon: 'camera', message: 'Screen capture needs a native MediaProjection consent flow. This preview does not capture silently.' },
  { label: 'Screen record', icon: 'video', message: 'Recording needs a native MediaProjection consent flow and foreground service in an Android build.' },
  { label: 'Brightness', icon: 'sun', message: 'Brightness control is device-specific and requires a native Android implementation.' },
  { label: 'Volume', icon: 'volume-2', message: 'Volume control is device-specific and requires a native Android implementation.' },
  { label: 'Rotate', icon: 'rotate-cw', message: 'Orientation shortcut is available to a native build; preview keeps the system orientation unchanged.' },
  { label: 'Touch lock', icon: 'lock', message: 'Touch lock needs an accessibility or native overlay implementation. It is not enabled in preview.' },
  { label: 'Notifications', icon: 'bell', message: 'Notification controls require Android notification access and are optional.' },
  { label: 'AI chat', icon: 'message-circle', message: '' },
];

type Message = { role: 'ai' | 'user'; text: string };

export default function ToolsScreen() {
  const insets = useSafeAreaInsets();
  const [chatVisible, setChatVisible] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([{ role: 'ai', text: 'wkwk lagi main apa? Aku bisa bantu tips gaming ringan atau troubleshooting.' }]);
  const pressTool = (tool: (typeof tools)[number]) => {
    if (tool.label === 'AI chat') setChatVisible(true);
    else Alert.alert(tool.label, tool.message);
  };
  const send = () => {
    if (!input.trim()) return;
    const userText = input.trim();
    const lower = userText.toLowerCase();
    const reply = lower.includes('gabut') ? 'wkwk sama. Lagi pengen push rank atau santai?' : lower.includes('lag') ? 'Coba cek sinyal, tutup app berat, lalu start session lagi. OPMOUS nggak bisa janji FPS naik ya.' : 'Siap. Aku masih mode offline, tapi bisa bantu tips umum dan cek langkah dasar.';
    setMessages((current) => [...current, { role: 'user', text: userText }, { role: 'ai', text: reply }]);
    setInput('');
  };
  return (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 }]} showsVerticalScrollIndicator={false}>
      <Text style={styles.kicker}>QUICK ACCESS</Text>
      <Text style={styles.title}>Gaming tools</Text>
      <Text style={styles.subtitle}>Shortcuts stay lightweight and ask for access only when you use them.</Text>
      <View style={styles.toolGrid}>{tools.map((tool) => <Pressable key={tool.label} onPress={() => pressTool(tool)} style={({ pressed }) => [styles.toolCard, pressed && styles.pressed]} testID={`tool-${tool.label.toLowerCase().replace(' ', '-')}`}><View style={styles.toolIcon}><Feather name={tool.icon as keyof typeof Feather.glyphMap} size={19} color={colors.light.primary} /></View><Text style={styles.toolLabel}>{tool.label}</Text><Feather name="arrow-up-right" size={14} color={colors.light.mutedForeground} /></Pressable>)}</View>
      <View style={styles.overlayCard}><View style={styles.overlayIcon}><Feather name="layers" size={20} color={colors.light.primary} /></View><View style={{ flex: 1 }}><Text style={styles.overlayTitle}>Floating panel</Text><Text style={styles.overlayText}>Overlay permission and a foreground service are required for a panel above games.</Text></View><Text style={styles.overlayStatus}>SETTINGS</Text></View>
      <Modal animationType="slide" transparent visible={chatVisible} onRequestClose={() => setChatVisible(false)}>
        <KeyboardAvoidingView style={styles.chatBackdrop} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={[styles.chatCard, { paddingBottom: insets.bottom + 12 }]}>
            <View style={styles.chatHeader}><View><Text style={styles.chatKicker}>OPMOUS AI</Text><Text style={styles.chatTitle}>Gaming buddy</Text></View><Pressable onPress={() => setChatVisible(false)}><Feather name="x" size={22} color={colors.light.mutedForeground} /></Pressable></View>
            <ScrollView style={styles.chatList} contentContainerStyle={{ gap: 10 }} showsVerticalScrollIndicator={false}>{messages.map((message, index) => <View key={`${message.role}-${index}`} style={[styles.bubble, message.role === 'user' ? styles.userBubble : styles.aiBubble]}><Text style={[styles.bubbleText, message.role === 'user' && styles.userBubbleText]}>{message.text}</Text></View>)}</ScrollView>
            <View style={styles.chatInputRow}><TextInput value={input} onChangeText={setInput} onSubmitEditing={send} returnKeyType="send" placeholder="Tulis pesan..." placeholderTextColor={colors.light.mutedForeground} style={styles.chatInput} /><Pressable onPress={send} style={styles.sendButton}><Feather name="send" size={17} color={colors.light.primaryForeground} /></Pressable></View>
            <Text style={styles.offlineText}>Offline fallback aktif · provider AI dapat diganti nanti</Text>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { backgroundColor: colors.light.background, minHeight: '100%', paddingHorizontal: 20 },
  kicker: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  title: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 31, letterSpacing: -0.6 },
  subtitle: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginBottom: 24, marginTop: 12 },
  toolGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  toolCard: { backgroundColor: colors.light.glass, borderColor: '#28555c', borderRadius: 17, borderWidth: 1, minHeight: 107, padding: 13, shadowColor: colors.light.violet, shadowOpacity: 0.1, shadowRadius: 12, width: '48%' },
  toolIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 11, height: 36, justifyContent: 'center', width: 36 },
  toolLabel: { color: colors.light.foreground, flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 15 },
  pressed: { opacity: 0.72 },
  overlayCard: { alignItems: 'center', backgroundColor: 'rgba(18, 37, 31, 0.84)', borderColor: '#477a61', borderRadius: 18, borderWidth: 1, flexDirection: 'row', gap: 12, marginTop: 22, padding: 14, shadowColor: colors.light.cyan, shadowOpacity: 0.16, shadowRadius: 16 },
  overlayIcon: { alignItems: 'center', backgroundColor: '#1c3a30', borderRadius: 12, height: 42, justifyContent: 'center', width: 42 },
  overlayTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  overlayText: { color: '#a8bbb4', fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 4 },
  overlayStatus: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.6 },
  chatBackdrop: { backgroundColor: 'rgba(0,0,0,0.65)', flex: 1, justifyContent: 'flex-end' },
  chatCard: { backgroundColor: colors.light.card, borderTopLeftRadius: 26, borderTopRightRadius: 26, minHeight: '72%', paddingHorizontal: 18, paddingTop: 18 },
  chatHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  chatKicker: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.7 },
  chatTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 5 },
  chatList: { flex: 1, marginVertical: 18 },
  bubble: { borderRadius: 15, maxWidth: '83%', paddingHorizontal: 13, paddingVertical: 10 },
  aiBubble: { alignSelf: 'flex-start', backgroundColor: colors.light.accent, borderBottomLeftRadius: 4 },
  userBubble: { alignSelf: 'flex-end', backgroundColor: colors.light.primary, borderBottomRightRadius: 4 },
  bubbleText: { color: colors.light.foreground, fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19 },
  userBubbleText: { color: colors.light.primaryForeground },
  chatInputRow: { alignItems: 'center', flexDirection: 'row', gap: 8 },
  chatInput: { backgroundColor: colors.light.background, borderColor: colors.light.border, borderRadius: 13, borderWidth: 1, color: colors.light.foreground, flex: 1, fontFamily: 'Inter_400Regular', fontSize: 13, paddingHorizontal: 13, paddingVertical: 12 },
  sendButton: { alignItems: 'center', backgroundColor: colors.light.primary, borderRadius: 13, height: 44, justifyContent: 'center', width: 44 },
  offlineText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 9, textAlign: 'center' },
});