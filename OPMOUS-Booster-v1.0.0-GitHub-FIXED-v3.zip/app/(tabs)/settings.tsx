import React from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useBooster, type Game } from '@/context/BoosterContext';
import colors from '@/constants/colors';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { profile, setProfile, liteMode, setLiteMode, panelEnabled, setPanelEnabled, hapticsEnabled, setHapticsEnabled } = useBooster();
  const profiles: Game['profile'][] = ['Balanced', 'Performance', 'Battery Saver'];
  const openSettings = () => Linking.openSettings().catch(() => Alert.alert('Unavailable', 'System settings could not be opened on this device.'));
  return (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 }]} showsVerticalScrollIndicator={false}>
      <Text style={styles.kicker}>CONTROL CENTER</Text>
      <Text style={styles.title}>Settings</Text>
      <Text style={styles.subtitle}>Tune OPMOUS itself, not the hardware. Android keeps CPU and GPU controls protected without root.</Text>
      <Text style={styles.sectionTitle}>Gaming profile</Text>
      <View style={styles.profileRow}>{profiles.map((item) => <Pressable key={item} onPress={() => setProfile(item)} style={[styles.profileOption, profile === item && styles.profileSelected]}><Feather name={item === 'Performance' ? 'zap' : item === 'Battery Saver' ? 'battery' : 'activity'} size={17} color={profile === item ? colors.light.primary : colors.light.mutedForeground} /><Text style={[styles.profileText, profile === item && styles.profileTextSelected]}>{item}</Text>{profile === item && <Feather name="check" size={15} color={colors.light.primary} />}</Pressable>)}</View>
      <Text style={styles.sectionTitle}>App behavior</Text>
      <SettingRow icon="layers" title="Floating gaming panel" description="Use only after overlay permission is granted." value={panelEnabled} onValueChange={setPanelEnabled} />
      <SettingRow icon="cpu" title="Lite mode" description="Less animation and slower monitoring to save resources." value={liteMode} onValueChange={setLiteMode} />
      <SettingRow icon="smartphone" title="Haptic feedback" description="Use small taps for important actions." value={hapticsEnabled} onValueChange={setHapticsEnabled} />
      <Text style={styles.sectionTitle}>Permission center</Text>
      <Pressable onPress={openSettings} style={styles.permissionRow}><View style={styles.permissionIcon}><Feather name="shield" size={18} color={colors.light.primary} /></View><View style={{ flex: 1 }}><Text style={styles.permissionTitle}>Review system permissions</Text><Text style={styles.permissionText}>Overlay, notifications, and battery optimization</Text></View><Feather name="external-link" size={17} color={colors.light.mutedForeground} /></Pressable>
      <View style={styles.about}><View style={styles.aboutTop}><View style={styles.logoMark}><Feather name="circle" size={25} color={colors.light.primary} /></View><View><Text style={styles.aboutName}>OPMOUS Booster</Text><Text style={styles.aboutVersion}>Version 1.0.0 · Boost. Monitor. Play.</Text></View></View><Text style={styles.aboutText}>No root. No hidden APIs. No fake performance numbers. Features that Android does not expose are marked clearly or routed to an official permission flow.</Text></View>
    </ScrollView>
  );
}

function SettingRow({ icon, title, description, value, onValueChange }: { icon: keyof typeof Feather.glyphMap; title: string; description: string; value: boolean; onValueChange: (value: boolean) => void }) {
  return <View style={styles.settingRow}><View style={styles.settingIcon}><Feather name={icon} size={17} color={colors.light.primary} /></View><View style={{ flex: 1 }}><Text style={styles.settingTitle}>{title}</Text><Text style={styles.settingText}>{description}</Text></View><Switch value={value} onValueChange={onValueChange} trackColor={{ false: colors.light.muted, true: '#587f2b' }} thumbColor={value ? colors.light.primary : colors.light.mutedForeground} /></View>;
}

const styles = StyleSheet.create({
  content: { backgroundColor: colors.light.background, minHeight: '100%', paddingHorizontal: 20 },
  kicker: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  title: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 31, letterSpacing: -0.6 },
  subtitle: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 12 },
  sectionTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 17, marginBottom: 11, marginTop: 28 },
  profileRow: { gap: 8 },
  profileOption: { alignItems: 'center', backgroundColor: colors.light.glass, borderColor: '#28555c', borderRadius: 14, borderWidth: 1, flexDirection: 'row', gap: 10, padding: 13 },
  profileSelected: { backgroundColor: colors.light.accent, borderColor: '#477b47' },
  profileText: { color: colors.light.mutedForeground, flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  profileTextSelected: { color: colors.light.foreground },
  settingRow: { alignItems: 'center', backgroundColor: colors.light.glass, borderColor: '#28555c', borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 11, marginBottom: 9, padding: 13 },
  settingIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 10, height: 34, justifyContent: 'center', width: 34 },
  settingTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  settingText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 4 },
  permissionRow: { alignItems: 'center', backgroundColor: 'rgba(18, 37, 31, 0.84)', borderColor: '#477a61', borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 11, padding: 13, shadowColor: colors.light.magenta, shadowOpacity: 0.12, shadowRadius: 16 },
  permissionIcon: { alignItems: 'center', backgroundColor: '#1c3a30', borderRadius: 10, height: 34, justifyContent: 'center', width: 34 },
  permissionTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  permissionText: { color: '#a8bbb4', fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4 },
  about: { backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 18, borderWidth: 1, marginTop: 24, padding: 16 },
  aboutTop: { alignItems: 'center', flexDirection: 'row', gap: 11 },
  logoMark: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 13, height: 46, justifyContent: 'center', width: 46 },
  aboutName: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 14 },
  aboutVersion: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4 },
  aboutText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, marginTop: 16 },
});