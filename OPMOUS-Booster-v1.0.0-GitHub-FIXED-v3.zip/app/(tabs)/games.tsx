import React, { useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useBooster, type Game } from '@/context/BoosterContext';
import colors from '@/constants/colors';

export default function GamesScreen() {
  const insets = useSafeAreaInsets();
  const { games, addGame, removeGame, launchGame, startSession, profile } = useBooster();
  const [modalVisible, setModalVisible] = useState(false);
  const [name, setName] = useState('');
  const [packageName, setPackageName] = useState('');

  const saveGame = () => {
    if (!name.trim()) {
      Alert.alert('Game name required', 'Give your shortcut a name first.');
      return;
    }
    addGame({ name: name.trim(), packageName: packageName.trim(), profile });
    setName('');
    setPackageName('');
    setModalVisible(false);
  };

  return (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 }]} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View>
          <Text style={styles.kicker}>LIBRARY</Text>
          <Text style={styles.title}>My Games</Text>
        </View>
        <Pressable onPress={() => setModalVisible(true)} style={styles.addButton} testID="add-game">
          <Feather name="plus" size={19} color={colors.light.primaryForeground} />
          <Text style={styles.addButtonText}>ADD GAME</Text>
        </Pressable>
      </View>
      <Text style={styles.subtitle}>Shortcuts live on this device. No game data leaves the app.</Text>

      {games.length === 0 ? (
        <View style={styles.empty}>
          <View style={styles.emptyIcon}><Feather name="grid" size={26} color={colors.light.primary} /></View>
          <Text style={styles.emptyTitle}>Your library is empty</Text>
          <Text style={styles.emptyText}>Add a game shortcut to start a session with a profile that fits how you play.</Text>
          <Pressable onPress={() => setModalVisible(true)} style={styles.outlineButton}><Text style={styles.outlineText}>ADD FIRST GAME</Text></Pressable>
        </View>
      ) : games.map((game) => <GameCard key={game.id} game={game} onPlay={() => { startSession(game.name); launchGame(game); }} onDelete={() => removeGame(game.id)} />)}

      <View style={styles.note}>
        <Feather name="info" size={16} color={colors.light.primary} />
        <Text style={styles.noteText}>Directly opening installed packages needs an Android native build. Preview mode keeps the shortcut and explains the limitation instead of pretending.</Text>
      </View>

      <Modal animationType="slide" transparent visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { paddingBottom: insets.bottom + 20 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}><Text style={styles.modalTitle}>Add a game</Text><Pressable onPress={() => setModalVisible(false)}><Feather name="x" size={22} color={colors.light.mutedForeground} /></Pressable></View>
            <Text style={styles.inputLabel}>GAME NAME</Text>
            <TextInput value={name} onChangeText={setName} placeholder="e.g. Apex Legends" placeholderTextColor={colors.light.mutedForeground} style={styles.input} autoCapitalize="words" />
            <Text style={styles.inputLabel}>ANDROID PACKAGE NAME <Text style={styles.optional}>OPTIONAL</Text></Text>
            <TextInput value={packageName} onChangeText={setPackageName} placeholder="e.g. com.example.game" placeholderTextColor={colors.light.mutedForeground} style={styles.input} autoCapitalize="none" />
            <Text style={styles.helper}>Used as a reference for a future native launcher. The preview never claims to open an installed app.</Text>
            <Pressable onPress={saveGame} style={styles.saveButton}><Text style={styles.saveText}>SAVE SHORTCUT</Text></Pressable>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

function GameCard({ game, onPlay, onDelete }: { game: Game; onPlay: () => void; onDelete: () => void }) {
  return (
    <View style={styles.gameCard}>
      <View style={styles.gameIcon}><Feather name="grid" size={24} color={colors.light.primary} /></View>
      <View style={styles.gameMain}><Text style={styles.gameName}>{game.name}</Text><Text style={styles.gameMeta}>{game.profile} profile{game.lastPlayed ? ' · Played recently' : ' · Not played yet'}</Text><Text style={styles.packageText}>{game.packageName || 'Package name not set'}</Text></View>
      <View style={styles.gameActions}>
        <Pressable onPress={onPlay} style={styles.playButton}><Feather name="play" size={14} color={colors.light.primaryForeground} /><Text style={styles.playText}>PLAY</Text></Pressable>
        <Pressable onPress={onDelete} style={styles.deleteButton}><Feather name="trash-2" size={16} color={colors.light.destructive} /></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { backgroundColor: colors.light.background, minHeight: '100%', paddingHorizontal: 20 },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  kicker: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  title: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 31, letterSpacing: -0.6 },
  subtitle: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginBottom: 24, marginTop: 12 },
  addButton: { alignItems: 'center', backgroundColor: colors.light.primary, borderRadius: 12, flexDirection: 'row', gap: 6, paddingHorizontal: 12, paddingVertical: 11 },
  addButtonText: { color: colors.light.primaryForeground, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.7 },
  empty: { alignItems: 'center', backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 22, borderWidth: 1, marginTop: 20, paddingHorizontal: 28, paddingVertical: 38 },
  emptyIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 18, height: 60, justifyContent: 'center', width: 60 },
  emptyTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 18, marginTop: 20 },
  emptyText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, marginTop: 9, textAlign: 'center' },
  outlineButton: { borderColor: colors.light.primary, borderRadius: 12, borderWidth: 1, marginTop: 22, paddingHorizontal: 16, paddingVertical: 12 },
  outlineText: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.8 },
  gameCard: { alignItems: 'center', backgroundColor: colors.light.glass, borderColor: '#28555c', borderRadius: 18, borderWidth: 1, flexDirection: 'row', gap: 12, marginBottom: 12, padding: 13, shadowColor: colors.light.cyan, shadowOpacity: 0.12, shadowRadius: 12 },
  gameIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 14, height: 50, justifyContent: 'center', width: 50 },
  gameMain: { flex: 1, minWidth: 0 },
  gameName: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  gameMeta: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 4 },
  packageText: { color: '#668277', fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 5 },
  gameActions: { alignItems: 'flex-end', gap: 10 },
  playButton: { alignItems: 'center', backgroundColor: colors.light.primary, borderRadius: 10, flexDirection: 'row', gap: 5, paddingHorizontal: 9, paddingVertical: 8 },
  playText: { color: colors.light.primaryForeground, fontFamily: 'Inter_700Bold', fontSize: 10 },
  deleteButton: { padding: 4 },
  note: { alignItems: 'flex-start', backgroundColor: colors.light.accent, borderRadius: 14, flexDirection: 'row', gap: 9, marginTop: 14, padding: 13 },
  noteText: { color: colors.light.mutedForeground, flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17 },
  modalBackdrop: { backgroundColor: 'rgba(0,0,0,0.65)', flex: 1, justifyContent: 'flex-end' },
  modalCard: { backgroundColor: colors.light.card, borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingHorizontal: 20, paddingTop: 10 },
  modalHandle: { alignSelf: 'center', backgroundColor: colors.light.border, borderRadius: 4, height: 4, marginBottom: 20, width: 42 },
  modalHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 22 },
  modalTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 21 },
  inputLabel: { color: colors.light.mutedForeground, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1, marginBottom: 8, marginTop: 12 },
  optional: { color: '#668277', fontFamily: 'Inter_500Medium', letterSpacing: 0 },
  input: { backgroundColor: colors.light.background, borderColor: colors.light.border, borderRadius: 12, borderWidth: 1, color: colors.light.foreground, fontFamily: 'Inter_400Regular', fontSize: 14, paddingHorizontal: 14, paddingVertical: 13 },
  helper: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, marginTop: 11 },
  saveButton: { alignItems: 'center', backgroundColor: colors.light.primary, borderRadius: 13, marginTop: 22, paddingVertical: 14 },
  saveText: { color: colors.light.primaryForeground, fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 0.7 },
});