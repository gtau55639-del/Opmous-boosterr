import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BrandMark } from '@/components/BrandMark';
import colors from '@/constants/colors';
import { useBooster } from '@/context/BoosterContext';

const formatTime = (seconds: number) =>
  [Math.floor(seconds / 3600), Math.floor((seconds % 3600) / 60), seconds % 60]
    .map((part) => String(part).padStart(2, '0'))
    .join(':');

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const landscape = width > height;
  const router = useRouter();
  const { games, isSessionActive, sessionSeconds, startSession, stopSession, profile } = useBooster();

  return (
    <ScrollView
      contentContainerStyle={[styles.content, landscape && styles.landscapeContent, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 110 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <BrandMark />
        <Pressable onPress={() => router.push('/settings')} style={styles.iconButton} testID="home-settings">
          <Feather name="sliders" size={19} color={colors.light.foreground} />
        </Pressable>
      </View>

      <View style={[styles.heroLayout, landscape && styles.heroLandscape]}>
        <View style={styles.heroCopy}>
          <View style={styles.eyebrowRow}>
            <View style={styles.liveDot} />
            <Text style={styles.eyebrow}>{isSessionActive ? 'SESSION ACTIVE' : 'GAMING READY'}</Text>
          </View>
          <Text style={styles.title}>Boost.{'\n'}Monitor. Play.</Text>
          <Text style={styles.subtitle}>
            A lightweight gaming assistant that stays honest about what Android allows.
          </Text>
        </View>
      <LinearGradient colors={['#112b2c', '#0b131a', '#161128']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.sessionCard, landscape && styles.heroLandscapeSession]}>
        <View style={styles.sessionGlow} />
        <View style={styles.cardTop}>
          <View>
            <Text style={styles.cardLabel}>{isSessionActive ? 'CURRENT SESSION' : 'READY TO PLAY'}</Text>
            <Text style={styles.timer}>{formatTime(sessionSeconds)}</Text>
          </View>
          <View style={styles.profileBadge}>
            <Feather name="sliders" size={13} color={colors.light.primary} />
            <Text style={styles.profileText}>{profile}</Text>
          </View>
        </View>
        <Text style={styles.sessionDescription}>
          {isSessionActive ? 'Monitoring is active while you play.' : 'Start a session to track what the device can report.'}
        </Text>
        <Pressable
          accessibilityRole="button"
          onPress={isSessionActive ? stopSession : () => startSession()}
          style={({ pressed }) => [styles.boostButton, pressed && styles.pressed]}
          testID="boost-session"
        >
          <Feather name={isSessionActive ? 'square' : 'zap'} size={17} color={colors.light.primaryForeground} />
          <Text style={styles.boostText}>{isSessionActive ? 'STOP SESSION' : 'START BOOST'}</Text>
        </Pressable>
      </LinearGradient>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Device pulse</Text>
        <Pressable onPress={() => router.push('/monitor')}><Text style={styles.link}>VIEW MONITOR</Text></Pressable>
      </View>
      <View style={styles.metricGrid}>
        {[
          ['Battery', 'Unavailable', 'battery'],
          ['Memory', 'Unavailable', 'database'],
          ['Temperature', 'Unavailable', 'thermometer'],
          ['Network', 'Ready', 'wifi'],
        ].map(([label, value, icon]) => (
          <View key={label} style={styles.metricCard}>
            <Feather name={icon as keyof typeof Feather.glyphMap} size={16} color={colors.light.primary} />
            <Text style={styles.metricLabel}>{label}</Text>
            <Text style={styles.metricValue}>{value}</Text>
          </View>
        ))}
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>My Games</Text>
        <Pressable onPress={() => router.push('/games')}><Text style={styles.link}>SEE ALL</Text></Pressable>
      </View>
      {games.length > 0 ? (
        <Pressable onPress={() => router.push('/games')} style={styles.gamePreview}>
          <View style={styles.gameIcon}><Feather name="grid" size={22} color={colors.light.primary} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.gameName}>{games[0].name}</Text>
            <Text style={styles.gameMeta}>{games.length > 1 ? `+${games.length - 1} more games` : games[0].profile}</Text>
          </View>
          <Feather name="arrow-up-right" size={19} color={colors.light.mutedForeground} />
        </Pressable>
      ) : (
        <Pressable onPress={() => router.push('/games')} style={styles.emptyCard}>
          <View style={styles.emptyIcon}><Feather name="plus" size={20} color={colors.light.primary} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.emptyTitle}>Add your first game</Text>
            <Text style={styles.emptyText}>Create a shortcut and choose its gaming profile.</Text>
          </View>
          <Feather name="chevron-right" size={18} color={colors.light.mutedForeground} />
        </Pressable>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { backgroundColor: colors.light.background, paddingHorizontal: 20 },
  landscapeContent: { paddingHorizontal: 34 },
  heroLayout: { gap: 0 },
  heroLandscape: { alignItems: 'stretch', flexDirection: 'row', gap: 24 },
  heroCopy: { flex: 1, justifyContent: 'center' },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 34 },
  iconButton: { alignItems: 'center', backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 14, borderWidth: 1, height: 42, justifyContent: 'center', width: 42 },
  eyebrowRow: { alignItems: 'center', flexDirection: 'row', gap: 8, marginBottom: 12 },
  liveDot: { backgroundColor: colors.light.primary, borderRadius: 4, height: 8, width: 8 },
  eyebrow: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.8 },
  title: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 42, letterSpacing: -1.4, lineHeight: 44 },
  subtitle: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 14, maxWidth: 320 },
  sessionCard: { borderColor: '#477a61', borderRadius: 24, borderWidth: 1, flex: 1.15, marginTop: 26, minWidth: 0, overflow: 'hidden', padding: 20, shadowColor: colors.light.cyan, shadowOpacity: 0.18, shadowRadius: 18 },
  heroLandscapeSession: { marginTop: 0 },
  sessionGlow: { backgroundColor: '#2d572e', borderRadius: 90, height: 130, opacity: 0.24, position: 'absolute', right: -44, top: -50, width: 170 },
  cardTop: { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'space-between' },
  cardLabel: { color: '#8fa59d', fontFamily: 'Inter_600SemiBold', fontSize: 10, letterSpacing: 1.5 },
  timer: { color: '#f4f7f5', fontFamily: 'Inter_700Bold', fontSize: 34, letterSpacing: 1, marginTop: 7 },
  profileBadge: { alignItems: 'center', backgroundColor: '#1c3a30', borderRadius: 12, flexDirection: 'row', gap: 6, paddingHorizontal: 10, paddingVertical: 8 },
  profileText: { color: colors.light.primary, fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  sessionDescription: { color: '#a8bbb4', fontFamily: 'Inter_400Regular', fontSize: 13, marginBottom: 18, marginTop: 14 },
  boostButton: { alignItems: 'center', backgroundColor: colors.light.primary, borderRadius: 14, flexDirection: 'row', gap: 8, justifyContent: 'center', paddingVertical: 14 },
  boostText: { color: colors.light.primaryForeground, fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1.1 },
  pressed: { opacity: 0.75 },
  sectionHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12, marginTop: 28 },
  sectionTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 17 },
  link: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1 },
  metricGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metricCard: { backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 16, borderWidth: 1, minHeight: 91, padding: 13, width: '48%' },
  metricLabel: { color: colors.light.mutedForeground, fontFamily: 'Inter_500Medium', fontSize: 12, marginTop: 12 },
  metricValue: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 4 },
  gamePreview: { alignItems: 'center', backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 18, borderWidth: 1, flexDirection: 'row', gap: 12, padding: 14 },
  gameIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 13, height: 46, justifyContent: 'center', width: 46 },
  gameName: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  gameMeta: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 4 },
  emptyCard: { alignItems: 'center', backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 18, borderStyle: 'dashed', borderWidth: 1, flexDirection: 'row', gap: 12, padding: 14 },
  emptyIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 13, height: 46, justifyContent: 'center', width: 46 },
  emptyTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  emptyText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 17, marginTop: 4 },
});