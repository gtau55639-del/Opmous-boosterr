import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useBooster } from '@/context/BoosterContext';
import colors from '@/constants/colors';

const metrics = [
  { label: 'CPU load', value: 'Unavailable', icon: 'cpu' },
  { label: 'Memory', value: 'Unavailable', icon: 'database' },
  { label: 'Temperature', value: 'Unavailable', icon: 'thermometer' },
  { label: 'Battery', value: 'Unavailable', icon: 'battery' },
  { label: 'Storage', value: 'Unavailable', icon: 'hard-drive' },
  { label: 'Network', value: 'Available', icon: 'wifi' },
];

export default function MonitorScreen() {
  const insets = useSafeAreaInsets();
  const { isSessionActive, sessionSeconds, liteMode } = useBooster();
  return (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 }]} showsVerticalScrollIndicator={false}>
      <Text style={styles.kicker}>LIVE TELEMETRY</Text>
      <Text style={styles.title}>Performance</Text>
      <View style={styles.statusCard}>
        <View style={styles.statusIcon}><Feather name={isSessionActive ? 'activity' : 'pause-circle'} size={22} color={colors.light.primary} /></View>
        <View style={{ flex: 1 }}><Text style={styles.statusTitle}>{isSessionActive ? 'Session monitoring active' : 'Monitoring is paused'}</Text><Text style={styles.statusText}>{isSessionActive ? `Running for ${formatTime(sessionSeconds)}` : 'Start a gaming session from Home to poll device data.'}</Text></View>
        <View style={[styles.statusPill, isSessionActive && styles.statusPillLive]}><Text style={[styles.statusPillText, isSessionActive && styles.statusPillTextLive]}>{isSessionActive ? 'LIVE' : 'IDLE'}</Text></View>
      </View>
      <Text style={styles.sectionTitle}>Device signals</Text>
      <View style={styles.metricGrid}>
        {metrics.map((metric) => <View key={metric.label} style={styles.metricCard}><View style={styles.metricIcon}><Feather name={metric.icon as keyof typeof Feather.glyphMap} size={17} color={colors.light.primary} /></View><Text style={styles.metricLabel}>{metric.label}</Text><Text style={styles.metricValue}>{metric.value}</Text></View>)}
      </View>
      <View style={styles.fpsCard}><View style={styles.fpsHeader}><Text style={styles.fpsTitle}>Frame rate</Text><Text style={styles.unavailable}>UNAVAILABLE</Text></View><Text style={styles.fpsValue}>—</Text><Text style={styles.fpsText}>Android does not expose reliable FPS data to a no-root app on every device. OPMOUS will never invent a number.</Text></View>
      <View style={styles.modeRow}><Feather name="cpu" size={18} color={colors.light.primary} /><View style={{ flex: 1 }}><Text style={styles.modeTitle}>OPMOUS resource mode</Text><Text style={styles.modeText}>{liteMode ? 'Lite mode · gentler polling and fewer effects' : 'Standard mode · balanced monitoring'}</Text></View><View style={styles.modeBadge}><Text style={styles.modeBadgeText}>{liteMode ? 'LITE' : 'STD'}</Text></View></View>
    </ScrollView>
  );
}

const formatTime = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
const styles = StyleSheet.create({
  content: { backgroundColor: colors.light.background, minHeight: '100%', paddingHorizontal: 20 },
  kicker: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  title: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 31, letterSpacing: -0.6, marginBottom: 20 },
  statusCard: { alignItems: 'center', backgroundColor: colors.light.glass, borderColor: '#28555c', borderRadius: 18, borderWidth: 1, flexDirection: 'row', gap: 12, padding: 14, shadowColor: colors.light.cyan, shadowOpacity: 0.12, shadowRadius: 12 },
  statusIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 13, height: 46, justifyContent: 'center', width: 46 },
  statusTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  statusText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 4 },
  statusPill: { backgroundColor: colors.light.muted, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 6 },
  statusPillLive: { backgroundColor: colors.light.accent },
  statusPillText: { color: colors.light.mutedForeground, fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.7 },
  statusPillTextLive: { color: colors.light.primary },
  sectionTitle: { color: colors.light.foreground, fontFamily: 'Inter_700Bold', fontSize: 17, marginBottom: 12, marginTop: 28 },
  metricGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metricCard: { backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 16, borderWidth: 1, minHeight: 101, padding: 13, width: '48%' },
  metricIcon: { alignItems: 'center', backgroundColor: colors.light.accent, borderRadius: 9, height: 30, justifyContent: 'center', width: 30 },
  metricLabel: { color: colors.light.mutedForeground, fontFamily: 'Inter_500Medium', fontSize: 11, marginTop: 11 },
  metricValue: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 4 },
  fpsCard: { backgroundColor: 'rgba(18, 37, 31, 0.84)', borderColor: '#477a61', borderRadius: 18, borderWidth: 1, marginTop: 22, padding: 17, shadowColor: colors.light.magenta, shadowOpacity: 0.12, shadowRadius: 16 },
  fpsHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  fpsTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  unavailable: { color: '#e5ae6c', fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.8 },
  fpsValue: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 40, marginTop: 12 },
  fpsText: { color: '#a8bbb4', fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, marginTop: 4 },
  modeRow: { alignItems: 'center', backgroundColor: colors.light.card, borderColor: colors.light.border, borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 12, marginTop: 12, padding: 14 },
  modeTitle: { color: colors.light.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  modeText: { color: colors.light.mutedForeground, fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4 },
  modeBadge: { backgroundColor: colors.light.accent, borderRadius: 7, paddingHorizontal: 7, paddingVertical: 5 },
  modeBadgeText: { color: colors.light.primary, fontFamily: 'Inter_700Bold', fontSize: 9 },
});