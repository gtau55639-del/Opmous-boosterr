/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#f4f7f5',
    tint: '#c7ff3d',

    // Core surfaces
    background: '#050809',
    foreground: '#f4f7f5',

    // Cards / elevated surfaces
    card: '#0d171a',
    cardForeground: '#f4f7f5',

    // Primary action color (buttons, links, active states)
    primary: '#c7ff3d',
    primaryForeground: '#08100f',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#12242a',
    secondaryForeground: '#d6e3dc',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#101b21',
    mutedForeground: '#86a0a6',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#12352f',
    accentForeground: '#c7ff3d',

    // Destructive actions (delete, error states)
    destructive: '#ff6f61',
    destructiveForeground: '#08100f',

    // Borders and input outlines
    border: '#214148',
    input: '#2b5960',

    // Cyber accents used for RGB edge lighting and status signals.
    cyan: '#2df0ff',
    magenta: '#ff3bd4',
    violet: '#8c6cff',
    glass: 'rgba(16, 31, 37, 0.78)',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
