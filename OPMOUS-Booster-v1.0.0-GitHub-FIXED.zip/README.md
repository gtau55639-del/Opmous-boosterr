# OPMOUS Booster

**Boost. Monitor. Play.**

OPMOUS Booster is a lightweight, no-root gaming assistant for Android. The first version focuses on honest device-aware tooling: local game shortcuts, gaming sessions, monitoring states, quick tools, offline gaming chat, and permission-aware fallbacks.

## Features

- Original OPMOUS visual identity and app icon
- Home dashboard with session controls
- Local My Games library with add, remove, profile, and play actions
- Balanced, Performance, and Battery Saver profiles
- Gaming session timer
- Device monitor surface that reports unavailable signals honestly
- Quick tools for screenshot, recording, brightness, volume, orientation, touch lock, notifications, and AI chat
- Offline OPMOUS AI fallback in casual Indonesian
- Permission-aware settings and overlay guidance
- AsyncStorage persistence for games and preferences

## Requirements

- Node.js 24+
- pnpm
- Expo Go for previewing on a physical device
- Android Studio and an Android SDK for a standalone Android build

## Android compatibility

The app is written with Expo and React Native for a fast first build. Features such as overlay windows, MediaProjection screenshot/recording, installed-package launching, and some system controls require an Android native build and explicit user consent. The preview marks those capabilities as unavailable instead of simulating them.

## Installation

```bash
pnpm install
pnpm --filter @workspace/opmous-booster run dev
```

Use Replit's mobile preview or the QR code with Expo Go.

## Build APK / AAB

This repository is prepared for Expo EAS Build.

```bash
npm install
npm install -g eas-cli
eas login
eas build:configure
```

For a directly installable Android APK:

```bash
eas build -p android --profile preview
```

For Google Play (AAB):

```bash
eas build -p android --profile production
```

The `eas.json` file is already included. GitHub stores the source code; EAS performs the Android build.

## Permissions

OPMOUS does not request every permission at startup. Overlay, notification access, battery optimization, and MediaProjection should be requested only when the matching feature is used in a native Android implementation.

## AI setup

The current first build uses an offline fallback so the app remains testable without a provider or API key. A future provider can be added behind the OPMOUS AI manager without putting credentials in source code.

## Limitations

- Expo preview cannot open arbitrary installed Android packages directly.
- Reliable FPS, CPU governor, GPU governor, overclocking, and guaranteed FPS increases are not available to a no-root app.
- Screenshot and recording need native MediaProjection consent and a foreground service.
- Floating panel needs `SYSTEM_ALERT_WINDOW` and Android service support.

## Troubleshooting

- If the preview does not update, restart the managed Expo workflow.
- If Android reports a missing permission, open the Permission Center and grant only the permission for the feature you are using.
- If a device signal says `Unavailable`, the Android API or current preview environment did not expose that signal.

## Roadmap

1. Android native module for overlay handle and floating gaming panel
2. MediaProjection screenshot and recording saved through MediaStore
3. Native installed-game discovery and launching
4. Optional AI provider through a server-side integration
5. Expanded profile actions that remain within Android's public APIs

## Safety

OPMOUS is intentionally no-root. It does not use Magisk, exploits, hidden APIs, ADB as a requirement, malware behavior, or unnecessary permissions.
## GitHub APK build

This project is configured for GitHub Actions + Expo EAS. The APK workflow intentionally uses `npm install` instead of `npm ci` because this repository does not require a committed `package-lock.json`.

Add an `EXPO_TOKEN` repository secret before running the APK workflow. Then open GitHub Actions and run **Build OPMOUS Booster APK**. The actual Android APK is produced by EAS Build.
